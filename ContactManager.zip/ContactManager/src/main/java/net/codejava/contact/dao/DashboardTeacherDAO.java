package net.codejava.contact.dao;

public interface DashboardTeacherDAO {

}
