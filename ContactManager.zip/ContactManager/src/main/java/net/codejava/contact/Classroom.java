package net.codejava.contact;

public class Classroom {
	private Integer classroomId;
	private String className;
	private Integer form;
	private String teacherName;

	public Integer getClassroomId() {
		return classroomId;
	}
	public void setClassroomId(Integer classroomId) {
		this.classroomId = classroomId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Integer getForm() {
		return form;
	}
	public void setForm(Integer form) {
		this.form = form;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
}
