package net.codejava.contact;

public class ClassParticipate {

	private Integer classParticipantId;
	private Integer classroomId;
	private Integer userId;
	
	public Integer getClassParticipantId() {
		return classParticipantId;
	}
	public void setClassParticipantId(Integer classParticipantId) {
		this.classParticipantId = classParticipantId;
	}
	public Integer getClassroomId() {
		return classroomId;
	}
	public void setClassroomId(Integer classroomId) {
		this.classroomId = classroomId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
}
