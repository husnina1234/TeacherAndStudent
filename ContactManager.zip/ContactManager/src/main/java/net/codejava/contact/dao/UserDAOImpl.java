package net.codejava.contact.dao;

import java.util.List;

import net.codejava.contact.User;

public class UserDAOImpl implements UserDAO {

	@Override
	public int save(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(User user) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int userID) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public User get(int userID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
