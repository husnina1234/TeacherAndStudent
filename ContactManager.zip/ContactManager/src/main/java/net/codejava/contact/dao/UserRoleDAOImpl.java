package net.codejava.contact.dao;

import java.util.List;

import net.codejava.contact.userRole;

public class UserRoleDAOImpl implements userRoleDAO {
	

	@Override
	public int save(userRole role ) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(userRole role) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int roleID) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public userRole get(int roleID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<userRole> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
