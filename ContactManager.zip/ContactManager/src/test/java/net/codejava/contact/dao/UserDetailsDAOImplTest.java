package net.codejava.contact.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UserDetailsDAOImplTest {

	@Test
	void testUserDetailsDAOImpl() {
		fail("Not yet implemented");
	}

	@Test
	void testSave() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	void testGetStudentById() {
		fail("Not yet implemented");
	}

	@Test
	void testTeacherList() {
		fail("Not yet implemented");
	}

	@Test
	void testUnassignedStudentList() {
		fail("Not yet implemented");
	}

	@Test
	void testStudentList() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPhotoById() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchStudentByName() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchStudentByIC() {
		fail("Not yet implemented");
	}

	@Test
	void testParticipantList() {
		fail("Not yet implemented");
	}

}
